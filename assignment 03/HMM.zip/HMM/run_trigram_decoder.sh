#!/bin/sh
python ViterbiTrigramDecoder.py --probs trigram_probs.txt --file mistyped_test --check


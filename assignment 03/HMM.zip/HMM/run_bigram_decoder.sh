#!/bin/sh
python ViterbiBigramDecoder.py --probs bigram_probs.txt --file mistyped_test --check


#!/bin/sh
python Aligner.py -s abcdefghij ABCDEFGHIJ

#!/bin/sh
python Aligner.py -f data/file2a.txt data/file2b.txt --check
 

#!/bin/sh
python Aligner.py -s arachnaphobic aristocratic

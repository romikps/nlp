#!/bin/sh
python Aligner.py -s above broke

#!/bin/sh
python Aligner.py -s recieve receive

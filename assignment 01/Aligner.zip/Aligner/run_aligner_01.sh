#!/bin/sh
python Aligner.py -s is has


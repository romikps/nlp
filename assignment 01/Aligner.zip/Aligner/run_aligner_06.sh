#!/bin/sh
python Aligner.py -s another therefore


#!/bin/sh
python Aligner.py -f data/file1a.txt data/file1b.txt --check
 
